from django.apps import AppConfig


class SectorsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sectors'
    verbose_name = 'Secteurs'
